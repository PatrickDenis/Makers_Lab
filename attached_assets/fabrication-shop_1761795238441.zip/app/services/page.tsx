import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

export default function ServicesPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <Image src="/logo.png" alt="Precision Fab & Design" width={40} height={40} />
            <span className="text-xl font-bold">Precision Fab & Design</span>
          </Link>
          <nav className="hidden md:flex gap-6">
            <Link href="/" className="text-sm font-medium transition-colors hover:text-primary">
              Home
            </Link>
            <Link href="/services" className="text-sm font-medium text-primary">
              Services
            </Link>
            <Link href="/gallery" className="text-sm font-medium transition-colors hover:text-primary">
              Gallery
            </Link>
            <Link href="/about" className="text-sm font-medium transition-colors hover:text-primary">
              About
            </Link>
            <Link href="/contact" className="text-sm font-medium transition-colors hover:text-primary">
              Contact
            </Link>
          </nav>
          <Button asChild className="hidden md:inline-flex">
            <Link href="/contact">Get a Quote</Link>
          </Button>
          <Button variant="outline" size="icon" className="md:hidden">
            <span className="sr-only">Toggle menu</span>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="h-6 w-6"
            >
              <line x1="4" x2="20" y1="12" y2="12" />
              <line x1="4" x2="20" y1="6" y2="6" />
              <line x1="4" x2="20" y1="18" y2="18" />
            </svg>
          </Button>
        </div>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 bg-muted">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl">Our Services</h1>
                <p className="max-w-[900px] text-muted-foreground md:text-xl">
                  Comprehensive fabrication and design solutions for all your manufacturing needs.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section id="3d-printing" className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-[1fr_400px] lg:gap-12 xl:grid-cols-[1fr_600px]">
              <div className="flex flex-col justify-center space-y-4">
                <div className="space-y-2">
                  <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl">3D Printing Services</h2>
                  <p className="max-w-[600px] text-muted-foreground md:text-xl">
                    From rapid prototyping to small production runs, our 3D printing services offer precision and
                    versatility.
                  </p>
                </div>
                <Accordion type="single" collapsible className="w-full">
                  <AccordionItem value="materials">
                    <AccordionTrigger>Materials We Work With</AccordionTrigger>
                    <AccordionContent>
                      <ul className="list-disc pl-6 space-y-2">
                        <li>PLA (Polylactic Acid)</li>
                        <li>ABS (Acrylonitrile Butadiene Styrene)</li>
                        <li>PETG (Polyethylene Terephthalate Glycol)</li>
                        <li>TPU (Thermoplastic Polyurethane) - Flexible</li>
                        <li>Nylon</li>
                        <li>Carbon Fiber Composites</li>
                        <li>Resin (SLA/DLP printing)</li>
                      </ul>
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="applications">
                    <AccordionTrigger>Common Applications</AccordionTrigger>
                    <AccordionContent>
                      <ul className="list-disc pl-6 space-y-2">
                        <li>Functional prototypes</li>
                        <li>Product development models</li>
                        <li>Custom fixtures and jigs</li>
                        <li>Replacement parts</li>
                        <li>Low-volume production runs</li>
                        <li>Architectural models</li>
                        <li>Medical models and devices</li>
                        <li>Educational props and demonstrations</li>
                      </ul>
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="process">
                    <AccordionTrigger>Our Process</AccordionTrigger>
                    <AccordionContent>
                      <ol className="list-decimal pl-6 space-y-2">
                        <li>
                          <strong>Design Review:</strong> We analyze your 3D model for printability
                        </li>
                        <li>
                          <strong>Material Selection:</strong> We help you choose the right material for your
                          application
                        </li>
                        <li>
                          <strong>Print Setup:</strong> Optimizing orientation and support structures
                        </li>
                        <li>
                          <strong>Printing:</strong> High-precision printing on industrial-grade equipment
                        </li>
                        <li>
                          <strong>Post-Processing:</strong> Support removal, sanding, and finishing as needed
                        </li>
                        <li>
                          <strong>Quality Control:</strong> Dimensional verification and functional testing
                        </li>
                        <li>
                          <strong>Delivery:</strong> Secure packaging and shipping of your finished parts
                        </li>
                      </ol>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
                <div className="flex flex-col gap-2 min-[400px]:flex-row pt-4">
                  <Button asChild>
                    <Link href="/contact">Request a Quote</Link>
                  </Button>
                </div>
              </div>
              <Image
                src="/placeholder.svg?height=550&width=800"
                width={550}
                height={550}
                alt="3D Printing Service"
                className="mx-auto aspect-video overflow-hidden rounded-xl object-cover sm:w-full lg:order-last"
              />
            </div>
          </div>
        </section>

        <section id="cnc-cutting" className="w-full py-12 md:py-24 lg:py-32 bg-muted">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-[400px_1fr] lg:gap-12 xl:grid-cols-[600px_1fr]">
              <Image
                src="/placeholder.svg?height=550&width=800"
                width={550}
                height={550}
                alt="CNC Cutting Service"
                className="mx-auto aspect-video overflow-hidden rounded-xl object-cover sm:w-full"
              />
              <div className="flex flex-col justify-center space-y-4">
                <div className="space-y-2">
                  <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl">CNC Cutting Services</h2>
                  <p className="max-w-[600px] text-muted-foreground md:text-xl">
                    Precision CNC cutting for a wide range of materials with exceptional accuracy and repeatability.
                  </p>
                </div>
                <Accordion type="single" collapsible className="w-full">
                  <AccordionItem value="materials">
                    <AccordionTrigger>Materials We Work With</AccordionTrigger>
                    <AccordionContent>
                      <ul className="list-disc pl-6 space-y-2">
                        <li>Aluminum</li>
                        <li>Steel</li>
                        <li>Stainless Steel</li>
                        <li>Brass</li>
                        <li>Copper</li>
                        <li>Plastics (Acrylic, Polycarbonate, HDPE, etc.)</li>
                        <li>Wood and Wood Composites</li>
                        <li>Foam</li>
                      </ul>
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="applications">
                    <AccordionTrigger>Common Applications</AccordionTrigger>
                    <AccordionContent>
                      <ul className="list-disc pl-6 space-y-2">
                        <li>Custom parts and components</li>
                        <li>Precision mechanical parts</li>
                        <li>Industrial equipment components</li>
                        <li>Automotive parts</li>
                        <li>Signage and displays</li>
                        <li>Furniture components</li>
                        <li>Architectural elements</li>
                        <li>Custom enclosures and housings</li>
                      </ul>
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="capabilities">
                    <AccordionTrigger>Our Capabilities</AccordionTrigger>
                    <AccordionContent>
                      <ul className="list-disc pl-6 space-y-2">
                        <li>
                          <strong>High Precision:</strong> Tolerances as tight as ±0.001"
                        </li>
                        <li>
                          <strong>Complex Geometries:</strong> Multi-axis machining for intricate designs
                        </li>
                        <li>
                          <strong>Various Finishes:</strong> From rough-cut to polished surfaces
                        </li>
                        <li>
                          <strong>Large Format:</strong> Capacity for sheets up to 5' x 10'
                        </li>
                        <li>
                          <strong>Small Batch to Production:</strong> Flexible capacity for any project size
                        </li>
                        <li>
                          <strong>Quick Turnaround:</strong> Rush services available for time-sensitive projects
                        </li>
                      </ul>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
                <div className="flex flex-col gap-2 min-[400px]:flex-row pt-4">
                  <Button asChild>
                    <Link href="/contact">Request a Quote</Link>
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="plasma-cutting" className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-[1fr_400px] lg:gap-12 xl:grid-cols-[1fr_600px]">
              <div className="flex flex-col justify-center space-y-4">
                <div className="space-y-2">
                  <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl">Plasma Cutting Services</h2>
                  <p className="max-w-[600px] text-muted-foreground md:text-xl">
                    High-temperature plasma cutting for thick metals and complex shapes with exceptional edge quality.
                  </p>
                </div>
                <Accordion type="single" collapsible className="w-full">
                  <AccordionItem value="materials">
                    <AccordionTrigger>Materials We Work With</AccordionTrigger>
                    <AccordionContent>
                      <ul className="list-disc pl-6 space-y-2">
                        <li>Mild Steel</li>
                        <li>Stainless Steel</li>
                        <li>Aluminum</li>
                        <li>Copper</li>
                        <li>Brass</li>
                        <li>Other conductive metals</li>
                      </ul>
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="applications">
                    <AccordionTrigger>Common Applications</AccordionTrigger>
                    <AccordionContent>
                      <ul className="list-disc pl-6 space-y-2">
                        <li>Heavy industrial components</li>
                        <li>Structural steel fabrication</li>
                        <li>Automotive parts</li>
                        <li>Custom metal art and signage</li>
                        <li>HVAC components</li>
                        <li>Agricultural equipment</li>
                        <li>Construction elements</li>
                        <li>Metal furniture</li>
                      </ul>
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="advantages">
                    <AccordionTrigger>Advantages of Plasma Cutting</AccordionTrigger>
                    <AccordionContent>
                      <ul className="list-disc pl-6 space-y-2">
                        <li>
                          <strong>Thick Material Capability:</strong> Can cut metal up to 2" thick
                        </li>
                        <li>
                          <strong>Speed:</strong> Faster than many alternative cutting methods
                        </li>
                        <li>
                          <strong>Precision:</strong> Computer-controlled for accurate, repeatable cuts
                        </li>
                        <li>
                          <strong>Clean Edges:</strong> Minimal heat-affected zone with high-quality finish
                        </li>
                        <li>
                          <strong>Complex Shapes:</strong> Ability to cut intricate designs and patterns
                        </li>
                        <li>
                          <strong>Cost-Effective:</strong> Economical for medium to large production runs
                        </li>
                      </ul>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
                <div className="flex flex-col gap-2 min-[400px]:flex-row pt-4">
                  <Button asChild>
                    <Link href="/contact">Request a Quote</Link>
                  </Button>
                </div>
              </div>
              <Image
                src="/placeholder.svg?height=550&width=800"
                width={550}
                height={550}
                alt="Plasma Cutting Service"
                className="mx-auto aspect-video overflow-hidden rounded-xl object-cover sm:w-full lg:order-last"
              />
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 lg:py-32 bg-muted">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl">Ready to Start Your Project?</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl">
                  Contact us today to discuss your fabrication needs and get a custom quote.
                </p>
              </div>
              <div className="flex flex-col gap-2 min-[400px]:flex-row">
                <Button asChild size="lg">
                  <Link href="/contact">Contact Us</Link>
                </Button>
                <Button asChild variant="outline" size="lg">
                  <Link href="/gallery">View Our Work</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="w-full border-t bg-background">
        <div className="container flex flex-col items-center justify-between gap-4 py-10 md:h-24 md:flex-row md:py-0">
          <div className="flex flex-col items-center gap-4 px-8 md:flex-row md:gap-2 md:px-0">
            <Image src="/logo.png" alt="Precision Fab & Design" width={30} height={30} />
            <p className="text-center text-sm leading-loose md:text-left">
              &copy; {new Date().getFullYear()} Precision Fab & Design. All rights reserved.
            </p>
          </div>
          <div className="flex gap-4">
            <Link href="/terms" className="text-sm text-muted-foreground underline-offset-4 hover:underline">
              Terms
            </Link>
            <Link href="/privacy" className="text-sm text-muted-foreground underline-offset-4 hover:underline">
              Privacy
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}

