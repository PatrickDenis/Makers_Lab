"use client"

import type React from "react"

import Link from "next/link"
import Image from "next/image"
import { useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Mail, MapPin, Phone, Clock, Menu, X } from "lucide-react"
import { useState } from "react"

export default function Home() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  // Refs for scrolling
  const servicesRef = useRef<HTMLElement>(null)
  const galleryRef = useRef<HTMLElement>(null)
  const aboutRef = useRef<HTMLElement>(null)
  const contactRef = useRef<HTMLElement>(null)

  // Scroll to section function
  const scrollToSection = (ref: React.RefObject<HTMLElement>) => {
    setMobileMenuOpen(false)
    if (ref.current) {
      ref.current.scrollIntoView({ behavior: "smooth" })
    }
  }

  return (
    <div className="flex flex-col min-h-screen bg-black text-white">
      <header className="sticky top-0 z-50 w-full border-b border-zinc-800 bg-black/95 backdrop-blur supports-[backdrop-filter]:bg-black/80">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/" className="flex items-center pl-4">
            <Image src="/ML-BKWT.png" alt="Maker's Lab Logo" width={40} height={40} className="mr-2" />
            <span className="text-2xl font-bold text-white">Maker's Lab</span>
          </Link>
          <nav className="hidden md:flex gap-8">
            <button
              onClick={() => scrollToSection(servicesRef)}
              className="text-sm font-medium text-zinc-400 transition-colors hover:text-white"
            >
              Services
            </button>
            <button
              onClick={() => scrollToSection(galleryRef)}
              className="text-sm font-medium text-zinc-400 transition-colors hover:text-white"
            >
              Gallery
            </button>
            <button
              onClick={() => scrollToSection(aboutRef)}
              className="text-sm font-medium text-zinc-400 transition-colors hover:text-white"
            >
              About
            </button>
            <button
              onClick={() => scrollToSection(contactRef)}
              className="text-sm font-medium text-zinc-400 transition-colors hover:text-white"
            >
              Contact
            </button>
          </nav>
          <div className="flex items-center gap-4">
            <Button asChild className="hidden md:inline-flex bg-white text-black hover:bg-zinc-200">
              <Link href="/quote">Request Quote</Link>
            </Button>
            <Button
              variant="outline"
              size="icon"
              className="md:hidden border-zinc-700 text-white hover:bg-zinc-800 hover:text-white"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              <span className="sr-only">Toggle menu</span>
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
        </div>
        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-zinc-900 border-b border-zinc-800">
            <div className="container py-4 flex flex-col space-y-4">
              <button
                onClick={() => scrollToSection(servicesRef)}
                className="text-sm font-medium text-zinc-400 transition-colors hover:text-white py-2"
              >
                Services
              </button>
              <button
                onClick={() => scrollToSection(galleryRef)}
                className="text-sm font-medium text-zinc-400 transition-colors hover:text-white py-2"
              >
                Gallery
              </button>
              <button
                onClick={() => scrollToSection(aboutRef)}
                className="text-sm font-medium text-zinc-400 transition-colors hover:text-white py-2"
              >
                About
              </button>
              <button
                onClick={() => scrollToSection(contactRef)}
                className="text-sm font-medium text-zinc-400 transition-colors hover:text-white py-2"
              >
                Contact
              </button>
              <Button asChild className="w-full bg-white text-black hover:bg-zinc-200">
                <Link href="/quote">Request Quote</Link>
              </Button>
            </div>
          </div>
        )}
      </header>
      <main className="flex-1">
        <section className="w-full py-16 md:py-24 lg:py-32 xl:py-40 bg-gradient-to-b from-black to-zinc-900">
          <div className="container px-4 md:px-6">
            <div className="grid gap-8 lg:grid-cols-[1fr_500px] lg:gap-12 xl:grid-cols-[1fr_550px] items-center">
              <div className="flex flex-col justify-center space-y-6">
                <div className="space-y-4">
                  <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none text-white">
                    Precision Fabrication & Design Solutions
                  </h1>
                  <p className="max-w-[600px] text-zinc-400 md:text-xl">
                    Expert 3D printing, CNC cutting, plasma cutting and Professional design services for your most
                    demanding projects.
                  </p>
                </div>
                <div className="flex flex-col gap-3 min-[400px]:flex-row">
                  <Button
                    onClick={() => scrollToSection(servicesRef)}
                    size="lg"
                    className="bg-white text-black hover:bg-zinc-200"
                  >
                    Explore Our Services
                  </Button>
                </div>
                <div className="flex items-center pt-4">
                  <button
                    onClick={() => scrollToSection(servicesRef)}
                    className="flex items-center text-sm text-zinc-400 hover:text-white"
                  >
                    Scroll to learn more
                    <Image src="/ML-BKWT.png" alt="Maker's Lab Logo" width={20} height={20} className="ml-2" />
                  </button>
                </div>
              </div>
              <div className="relative">
                <div className="absolute -inset-1 bg-gradient-to-r from-zinc-500 to-zinc-600 rounded-xl blur-xl opacity-20"></div>
                <div className="relative mx-auto flex items-center justify-center aspect-video overflow-hidden rounded-xl sm:w-full border border-zinc-800 bg-black p-12">
                  <Image
                    src="/ML-BKWT.png"
                    width={400}
                    height={400}
                    alt="Maker's Lab Logo"
                    className="w-full h-auto max-w-[400px]"
                  />
                </div>
              </div>
            </div>
          </div>
        </section>

        <section ref={servicesRef} id="services" className="w-full py-16 md:py-24 lg:py-32 bg-zinc-900">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
              <div className="inline-block rounded-lg bg-zinc-800 px-3 py-1 text-sm text-white">Our Expertise</div>
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl text-white">Our Services</h2>
                <p className="max-w-[900px] text-zinc-400 md:text-xl">
                  We offer a comprehensive range of fabrication and design services to bring your ideas to life.
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-6xl items-center gap-8 py-8 md:grid-cols-2 lg:grid-cols-4 lg:gap-8">
              <Card className="relative overflow-hidden border-zinc-800 bg-zinc-900/50 shadow-md transition-all hover:shadow-xl hover:shadow-zinc-900/20">
                <CardHeader className="pb-2">
                  <div className="w-12 h-12 rounded-lg bg-zinc-800 flex items-center justify-center mb-2">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="h-6 w-6 text-white"
                    >
                      <path d="M17 17H8a5 5 0 0 1 0-10H9" />
                      <path d="M13 7h4a5 5 0 0 1 0 10h-1" />
                    </svg>
                  </div>
                  <CardTitle className="text-xl text-white">3D Printing</CardTitle>
                  <CardDescription className="text-zinc-400">Rapid prototyping and production</CardDescription>
                </CardHeader>
                <CardContent>
                  <Image
                    src="/images/3d-printing.png"
                    width={400}
                    height={300}
                    alt="3D Printing Service"
                    className="aspect-video rounded-md object-cover mb-4 border border-zinc-800"
                  />
                  <div>
                    <p className="text-sm text-zinc-400">
                      High-precision 3D printing services for prototypes, custom parts, and small production runs.
                    </p>
                    <ul className="mt-4 space-y-1 text-sm text-zinc-400">
                      <li className="flex items-center">
                        <span className="mr-2 h-1 w-1 rounded-full bg-white"></span>
                        Multiple materials available
                      </li>
                      <li className="flex items-center">
                        <span className="mr-2 h-1 w-1 rounded-full bg-white"></span>
                        Tight tolerances
                      </li>
                      <li className="flex items-center">
                        <span className="mr-2 h-1 w-1 rounded-full bg-white"></span>
                        Fast turnaround times
                      </li>
                    </ul>
                  </div>
                </CardContent>
                <CardFooter>
                  <Accordion type="single" collapsible className="w-full">
                    <AccordionItem value="details" className="border-none">
                      <AccordionTrigger className="text-sm font-medium text-white py-0">View Details</AccordionTrigger>
                      <AccordionContent className="text-sm text-zinc-400">
                        <div className="space-y-2 pt-2">
                          <p className="font-medium text-zinc-300">Materials we work with:</p>
                          <ul className="list-disc pl-5 space-y-1">
                            <li>PLA, ABS, PETG</li>
                            <li>TPU (Flexible)</li>
                            <li>Nylon, Carbon Fiber</li>
                            <li>Resin (SLA/DLP)</li>
                          </ul>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                </CardFooter>
              </Card>
              <Card className="relative overflow-hidden border-zinc-800 bg-zinc-900/50 shadow-md transition-all hover:shadow-xl hover:shadow-zinc-900/20">
                <CardHeader className="pb-2">
                  <div className="w-12 h-12 rounded-lg bg-zinc-800 flex items-center justify-center mb-2">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="h-6 w-6 text-white"
                    >
                      <path d="M3 7V5a2 2 0 0 1 2-2h2" />
                      <path d="M17 3h2a2 2 0 0 1 2 2v2" />
                      <path d="M21 17v2a2 2 0 0 1-2 2h-2" />
                      <path d="M7 21H5a2 2 0 0 1-2-2v-2" />
                      <rect width="7" height="7" x="7" y="7" rx="1" />
                      <rect width="7" height="7" x="10" y="10" rx="1" />
                    </svg>
                  </div>
                  <CardTitle className="text-xl text-white">CNC Cutting</CardTitle>
                  <CardDescription className="text-zinc-400">Precision machining solutions</CardDescription>
                </CardHeader>
                <CardContent>
                  <Image
                    src="/images/cnc-cutting.png"
                    width={400}
                    height={300}
                    alt="CNC Cutting Service"
                    className="aspect-video rounded-md object-cover mb-4 border border-zinc-800"
                  />
                  <div>
                    <p className="text-sm text-zinc-400">
                      Computer-controlled cutting for precise, repeatable results across a variety of materials.
                    </p>
                    <ul className="mt-4 space-y-1 text-sm text-zinc-400">
                      <li className="flex items-center">
                        <span className="mr-2 h-1 w-1 rounded-full bg-white"></span>
                        High precision (±0.001")
                      </li>
                      <li className="flex items-center">
                        <span className="mr-2 h-1 w-1 rounded-full bg-white"></span>
                        Multi-axis machining
                      </li>
                      <li className="flex items-center">
                        <span className="mr-2 h-1 w-1 rounded-full bg-white"></span>
                        Complex geometries
                      </li>
                    </ul>
                  </div>
                </CardContent>
                <CardFooter>
                  <Accordion type="single" collapsible className="w-full">
                    <AccordionItem value="details" className="border-none">
                      <AccordionTrigger className="text-sm font-medium text-white py-0">View Details</AccordionTrigger>
                      <AccordionContent className="text-sm text-zinc-400">
                        <div className="space-y-2 pt-2">
                          <p className="font-medium text-zinc-300">Materials we work with:</p>
                          <ul className="list-disc pl-5 space-y-1">
                            <li>Aluminum, Steel, Stainless Steel</li>
                            <li>Brass, Copper</li>
                            <li>Plastics (Acrylic, Polycarbonate)</li>
                            <li>Wood and Composites</li>
                          </ul>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                </CardFooter>
              </Card>
              <Card className="relative overflow-hidden border-zinc-800 bg-zinc-900/50 shadow-md transition-all hover:shadow-xl hover:shadow-zinc-900/20">
                <CardHeader className="pb-2">
                  <div className="w-12 h-12 rounded-lg bg-zinc-800 flex items-center justify-center mb-2">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="h-6 w-6 text-white"
                    >
                      <path d="M12 2v8" />
                      <path d="m4.93 10.93 1.41 1.41" />
                      <path d="M2 18h2" />
                      <path d="M20 18h2" />
                      <path d="m19.07 10.93-1.41 1.41" />
                      <path d="M22 22H2" />
                      <path d="m16 6-4 4-4-4" />
                      <path d="M16 18a4 4 0 0 0-8 0" />
                    </svg>
                  </div>
                  <CardTitle className="text-xl text-white">Plasma Cutting</CardTitle>
                  <CardDescription className="text-zinc-400">Heavy-duty metal fabrication</CardDescription>
                </CardHeader>
                <CardContent>
                  <Image
                    src="/images/plasma-cutting.png"
                    width={400}
                    height={300}
                    alt="Plasma Cutting Service"
                    className="aspect-video rounded-md object-cover mb-4 border border-zinc-800"
                  />
                  <div>
                    <p className="text-sm text-zinc-400">
                      High-temperature plasma cutting for thick metals and complex shapes with exceptional edge quality.
                    </p>
                    <ul className="mt-4 space-y-1 text-sm text-zinc-400">
                      <li className="flex items-center">
                        <span className="mr-2 h-1 w-1 rounded-full bg-white"></span>
                        Cuts up to 2" thick metal
                      </li>
                      <li className="flex items-center">
                        <span className="mr-2 h-1 w-1 rounded-full bg-white"></span>
                        Clean, precise cuts
                      </li>
                      <li className="flex items-center">
                        <span className="mr-2 h-1 w-1 rounded-full bg-white"></span>
                        Intricate designs possible
                      </li>
                    </ul>
                  </div>
                </CardContent>
                <CardFooter>
                  <Accordion type="single" collapsible className="w-full">
                    <AccordionItem value="details" className="border-none">
                      <AccordionTrigger className="text-sm font-medium text-white py-0">View Details</AccordionTrigger>
                      <AccordionContent className="text-sm text-zinc-400">
                        <div className="space-y-2 pt-2">
                          <p className="font-medium text-zinc-300">Materials we work with:</p>
                          <ul className="list-disc pl-5 space-y-1">
                            <li>Mild Steel</li>
                            <li>Stainless Steel</li>
                            <li>Aluminum</li>
                            <li>Other conductive metals</li>
                          </ul>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                </CardFooter>
              </Card>
              <Card className="relative overflow-hidden border-zinc-800 bg-zinc-900/50 shadow-md transition-all hover:shadow-xl hover:shadow-zinc-900/20">
                <CardHeader className="pb-2">
                  <div className="w-12 h-12 rounded-lg bg-zinc-800 flex items-center justify-center mb-2">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="h-6 w-6 text-white"
                    >
                      <path d="M21 7v6h-6" />
                      <path d="M3 17a9 9 0 0 1 9-9 9 9 0 0 1 6 2.3l3 2.7" />
                    </svg>
                  </div>
                  <CardTitle className="text-xl text-white">3D CAD Design</CardTitle>
                  <CardDescription className="text-zinc-400">Professional design services</CardDescription>
                </CardHeader>
                <CardContent>
                  <Image
                    src="/images/3d-cad-design.png"
                    width={400}
                    height={300}
                    alt="3D CAD Design Service"
                    className="aspect-video rounded-md object-cover mb-4 border border-zinc-800"
                  />
                  <div>
                    <p className="text-sm text-zinc-400">
                      Expert 3D CAD design services to transform your ideas into detailed, manufacturable models and
                      technical drawings.
                    </p>
                    <ul className="mt-4 space-y-1 text-sm text-zinc-400">
                      <li className="flex items-center">
                        <span className="mr-2 h-1 w-1 rounded-full bg-white"></span>
                        Concept development
                      </li>
                      <li className="flex items-center">
                        <span className="mr-2 h-1 w-1 rounded-full bg-white"></span>
                        Detailed 3D modeling
                      </li>
                      <li className="flex items-center">
                        <span className="mr-2 h-1 w-1 rounded-full bg-white"></span>
                        Design for manufacturing
                      </li>
                    </ul>
                  </div>
                </CardContent>
                <CardFooter>
                  <Accordion type="single" collapsible className="w-full">
                    <AccordionItem value="details" className="border-none">
                      <AccordionTrigger className="text-sm font-medium text-white py-0">View Details</AccordionTrigger>
                      <AccordionContent className="text-sm text-zinc-400">
                        <div className="space-y-2 pt-2">
                          <p className="font-medium text-zinc-300">Our design capabilities:</p>
                          <ul className="list-disc pl-5 space-y-1">
                            <li>Mechanical parts and assemblies</li>
                            <li>Product design and prototyping</li>
                            <li>Technical drawings and documentation</li>
                            <li>Reverse engineering</li>
                          </ul>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                </CardFooter>
              </Card>
            </div>
            <div className="flex justify-center mt-8">
              <Button asChild size="lg" className="bg-white text-black hover:bg-zinc-200">
                <Link href="/quote">Request a Quote</Link>
              </Button>
            </div>
          </div>
        </section>

        <section className="w-full py-16 md:py-24 lg:py-32 bg-black">
          <div className="container px-4 md:px-6">
            <div className="grid gap-8 lg:grid-cols-2 lg:gap-12 items-center">
              <div className="relative order-2 lg:order-1">
                <div className="absolute -inset-1 bg-gradient-to-r from-zinc-500 to-zinc-600 rounded-xl blur-xl opacity-20"></div>
                <Image
                  src="/placeholder.svg?height=550&width=800"
                  width={550}
                  height={550}
                  alt="Workshop Image"
                  className="relative mx-auto aspect-video overflow-hidden rounded-xl object-cover sm:w-full border border-zinc-800"
                />
              </div>
              <div className="flex flex-col justify-center space-y-6 order-1 lg:order-2">
                <div className="inline-block rounded-lg bg-zinc-800 px-3 py-1 text-sm text-white w-fit">
                  Our Process
                </div>
                <div className="space-y-2">
                  <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl text-white">
                    From Concept to Creation
                  </h2>
                  <p className="max-w-[600px] text-zinc-400 md:text-lg">
                    We work closely with you at every stage of the process to ensure your vision becomes reality.
                  </p>
                </div>
                <Tabs defaultValue="design" className="w-full">
                  <TabsList className="grid w-full grid-cols-3 bg-zinc-800 text-zinc-400">
                    <TabsTrigger
                      value="design"
                      className="data-[state=active]:bg-zinc-900 data-[state=active]:text-white"
                    >
                      Design
                    </TabsTrigger>
                    <TabsTrigger
                      value="fabrication"
                      className="data-[state=active]:bg-zinc-900 data-[state=active]:text-white"
                    >
                      Fabrication
                    </TabsTrigger>
                    <TabsTrigger
                      value="delivery"
                      className="data-[state=active]:bg-zinc-900 data-[state=active]:text-white"
                    >
                      Delivery
                    </TabsTrigger>
                  </TabsList>
                  <TabsContent
                    value="design"
                    className="space-y-4 mt-4 border border-zinc-800 rounded-lg p-4 bg-zinc-900"
                  >
                    <h3 className="text-lg font-bold text-white">Expert Design Services</h3>
                    <p className="text-zinc-400">
                      Our team of skilled designers will help refine your ideas and create detailed plans for
                      production. We use industry-standard CAD software to ensure precision and manufacturability.
                    </p>
                    <ul className="space-y-1 text-sm text-zinc-400">
                      <li className="flex items-center">
                        <span className="mr-2 h-1 w-1 rounded-full bg-white"></span>
                        3D modeling and rendering
                      </li>
                      <li className="flex items-center">
                        <span className="mr-2 h-1 w-1 rounded-full bg-white"></span>
                        Technical drawings
                      </li>
                      <li className="flex items-center">
                        <span className="mr-2 h-1 w-1 rounded-full bg-white"></span>
                        Design for manufacturability
                      </li>
                    </ul>
                  </TabsContent>
                  <TabsContent
                    value="fabrication"
                    className="space-y-4 mt-4 border border-zinc-800 rounded-lg p-4 bg-zinc-900"
                  >
                    <h3 className="text-lg font-bold text-white">Precision Fabrication</h3>
                    <p className="text-zinc-400">
                      Using state-of-the-art equipment, we bring your designs to life with meticulous attention to
                      detail. Our skilled technicians ensure every piece meets our high quality standards.
                    </p>
                    <ul className="space-y-1 text-sm text-zinc-400">
                      <li className="flex items-center">
                        <span className="mr-2 h-1 w-1 rounded-full bg-white"></span>
                        Material selection guidance
                      </li>
                      <li className="flex items-center">
                        <span className="mr-2 h-1 w-1 rounded-full bg-white"></span>
                        Precision manufacturing
                      </li>
                      <li className="flex items-center">
                        <span className="mr-2 h-1 w-1 rounded-full bg-white"></span>
                        Quality control at every step
                      </li>
                    </ul>
                  </TabsContent>
                  <TabsContent
                    value="delivery"
                    className="space-y-4 mt-4 border border-zinc-800 rounded-lg p-4 bg-zinc-900"
                  >
                    <h3 className="text-lg font-bold text-white">Timely Delivery</h3>
                    <p className="text-zinc-400">
                      We ensure your finished products are delivered on schedule and meet your exact specifications. Our
                      logistics team handles packaging and shipping with care.
                    </p>
                    <ul className="space-y-1 text-sm text-zinc-400">
                      <li className="flex items-center">
                        <span className="mr-2 h-1 w-1 rounded-full bg-white"></span>
                        Secure packaging
                      </li>
                      <li className="flex items-center">
                        <span className="mr-2 h-1 w-1 rounded-full bg-white"></span>
                        Reliable shipping options
                      </li>
                      <li className="flex items-center">
                        <span className="mr-2 h-1 w-1 rounded-full bg-white"></span>
                        On-time delivery guarantee
                      </li>
                    </ul>
                  </TabsContent>
                </Tabs>
                <div className="flex flex-col gap-2 min-[400px]:flex-row pt-2">
                  <Button asChild size="lg" className="bg-white text-black hover:bg-zinc-200">
                    <Link href="/quote">Start Your Project</Link>
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section ref={galleryRef} id="gallery" className="w-full py-16 md:py-24 lg:py-32 bg-zinc-900">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
              <div className="inline-block rounded-lg bg-zinc-800 px-3 py-1 text-sm text-white">Our Portfolio</div>
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl text-white">
                  Featured Projects
                </h2>
                <p className="max-w-[900px] text-zinc-400 md:text-xl">
                  Browse our portfolio of completed projects across various industries and applications.
                </p>
              </div>
            </div>

            <Tabs defaultValue="all" className="w-full">
              <div className="flex justify-center mb-8">
                <TabsList className="bg-zinc-800 text-zinc-400">
                  <TabsTrigger value="all" className="data-[state=active]:bg-zinc-900 data-[state=active]:text-white">
                    All Projects
                  </TabsTrigger>
                  <TabsTrigger
                    value="3d-printing"
                    className="data-[state=active]:bg-zinc-900 data-[state=active]:text-white"
                  >
                    3D Printing
                  </TabsTrigger>
                  <TabsTrigger
                    value="cnc-cutting"
                    className="data-[state=active]:bg-zinc-900 data-[state=active]:text-white"
                  >
                    CNC Cutting
                  </TabsTrigger>
                  <TabsTrigger
                    value="plasma-cutting"
                    className="data-[state=active]:bg-zinc-900 data-[state=active]:text-white"
                  >
                    Plasma Cutting
                  </TabsTrigger>
                </TabsList>
              </div>
              <TabsContent value="all" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {[...Array(6)].map((_, i) => (
                    <div
                      key={i}
                      className="group overflow-hidden rounded-lg border border-zinc-800 bg-zinc-900/50 shadow-md transition-all hover:shadow-xl hover:shadow-zinc-900/20"
                    >
                      <div className="relative overflow-hidden">
                        <Image
                          src={`/placeholder.svg?height=300&width=400&text=Project+${i + 1}`}
                          width={400}
                          height={300}
                          alt={`Project ${i + 1}`}
                          className="aspect-video object-cover w-full transition-transform duration-300 group-hover:scale-105"
                        />
                      </div>
                      <div className="p-4">
                        <h3 className="font-bold text-white">Project {i + 1}</h3>
                        <p className="text-sm text-zinc-400 mt-1">
                          {i % 3 === 0
                            ? "3D Printed prototype for aerospace application"
                            : i % 3 === 1
                              ? "CNC machined aluminum components"
                              : "Plasma cut steel signage"}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </TabsContent>
              <TabsContent value="3d-printing" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {[...Array(3)].map((_, i) => (
                    <div
                      key={i}
                      className="group overflow-hidden rounded-lg border border-zinc-800 bg-zinc-900/50 shadow-md transition-all hover:shadow-xl hover:shadow-zinc-900/20"
                    >
                      <div className="relative overflow-hidden">
                        <Image
                          src={`/placeholder.svg?height=300&width=400&text=3D+Print+${i + 1}`}
                          width={400}
                          height={300}
                          alt={`3D Print Project ${i + 1}`}
                          className="aspect-video object-cover w-full transition-transform duration-300 group-hover:scale-105"
                        />
                      </div>
                      <div className="p-4">
                        <h3 className="font-bold text-white">3D Print Project {i + 1}</h3>
                        <p className="text-sm text-zinc-400 mt-1">3D Printed prototype for aerospace application</p>
                      </div>
                    </div>
                  ))}
                </div>
              </TabsContent>
              <TabsContent value="cnc-cutting" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {[...Array(3)].map((_, i) => (
                    <div
                      key={i}
                      className="group overflow-hidden rounded-lg border border-zinc-800 bg-zinc-900/50 shadow-md transition-all hover:shadow-xl hover:shadow-zinc-900/20"
                    >
                      <div className="relative overflow-hidden">
                        <Image
                          src={`/placeholder.svg?height=300&width=400&text=CNC+Project+${i + 1}`}
                          width={400}
                          height={300}
                          alt={`CNC Project ${i + 1}`}
                          className="aspect-video object-cover w-full transition-transform duration-300 group-hover:scale-105"
                        />
                      </div>
                      <div className="p-4">
                        <h3 className="font-bold text-white">CNC Project {i + 1}</h3>
                        <p className="text-sm text-zinc-400 mt-1">CNC machined aluminum components</p>
                      </div>
                    </div>
                  ))}
                </div>
              </TabsContent>
              <TabsContent value="plasma-cutting" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {[...Array(3)].map((_, i) => (
                    <div
                      key={i}
                      className="group overflow-hidden rounded-lg border border-zinc-800 bg-zinc-900/50 shadow-md transition-all hover:shadow-xl hover:shadow-zinc-900/20"
                    >
                      <div className="relative overflow-hidden">
                        <Image
                          src={`/placeholder.svg?height=300&width=400&text=Plasma+Project+${i + 1}`}
                          width={400}
                          height={300}
                          alt={`Plasma Project ${i + 1}`}
                          className="aspect-video object-cover w-full transition-transform duration-300 group-hover:scale-105"
                        />
                      </div>
                      <div className="p-4">
                        <h3 className="font-bold text-white">Plasma Project {i + 1}</h3>
                        <p className="text-sm text-zinc-400 mt-1">Plasma cut steel signage</p>
                      </div>
                    </div>
                  ))}
                </div>
              </TabsContent>
            </Tabs>

            <div className="flex justify-center mt-12">
              <Button
                asChild
                variant="outline"
                size="lg"
                className="border-zinc-700 text-white hover:bg-zinc-800 hover:text-white"
              >
                <Link href="/gallery">View All Projects</Link>
              </Button>
            </div>
          </div>
        </section>

        <section ref={aboutRef} id="about" className="w-full py-16 md:py-24 lg:py-32 bg-black">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
              <div className="inline-block rounded-lg bg-zinc-800 px-3 py-1 text-sm text-white">Who We Are</div>
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl text-white">
                  About Our Company
                </h2>
                <p className="max-w-[900px] text-zinc-400 md:text-xl">
                  Precision Fab & Design is a full-service fabrication and design shop with a passion for quality and
                  innovation.
                </p>
              </div>
            </div>

            <div className="grid gap-8 lg:grid-cols-2 lg:gap-12 items-center">
              <div className="space-y-6">
                <div className="space-y-4">
                  <h3 className="text-2xl font-bold text-white">Our Story</h3>
                  <p className="text-zinc-400">
                    Founded in 2010, Precision Fab & Design began as a small workshop with a single CNC machine and a
                    passion for precision manufacturing. What started as a one-person operation has grown into a
                    full-service fabrication shop with state-of-the-art equipment and a team of skilled technicians.
                  </p>
                  <p className="text-zinc-400">
                    Our journey has been driven by a commitment to quality, innovation, and customer satisfaction. Over
                    the years, we've expanded our capabilities to include 3D printing, CNC cutting, and plasma cutting
                    services, allowing us to serve a diverse range of industries.
                  </p>
                </div>

                <div className="space-y-4">
                  <h3 className="text-2xl font-bold text-white">Our Mission</h3>
                  <p className="text-zinc-400">
                    We strive to deliver exceptional fabrication services that bring our clients' visions to life with
                    precision, quality, and innovation. Our goal is to be the trusted partner for all your manufacturing
                    needs.
                  </p>
                </div>

                <div className="grid grid-cols-3 gap-4 pt-4">
                  <div className="flex flex-col items-center space-y-2 border border-zinc-800 rounded-lg p-4 bg-zinc-900">
                    <div className="flex h-12 w-12 items-center justify-center rounded-full bg-zinc-800">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="h-6 w-6 text-white"
                      >
                        <path d="M18 6H5a2 2 0 0 0-2 2v3a2 2 0 0 0 2 2h13l4-3.5L18 6Z" />
                        <path d="M12 13v8" />
                        <path d="M5 13v6a2 2 0 0 0 2 2h8" />
                      </svg>
                    </div>
                    <h3 className="text-base font-bold text-white text-center">Innovation</h3>
                  </div>
                  <div className="flex flex-col items-center space-y-2 border border-zinc-800 rounded-lg p-4 bg-zinc-900">
                    <div className="flex h-12 w-12 items-center justify-center rounded-full bg-zinc-800">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="h-6 w-6 text-white"
                      >
                        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10" />
                      </svg>
                    </div>
                    <h3 className="text-base font-bold text-white text-center">Quality</h3>
                  </div>
                  <div className="flex flex-col items-center space-y-2 border border-zinc-800 rounded-lg p-4 bg-zinc-900">
                    <div className="flex h-12 w-12 items-center justify-center rounded-full bg-zinc-800">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="h-6 w-6 text-white"
                      >
                        <path d="M12 22v-5" />
                        <path d="M9 8V2" />
                        <path d="M15 8V2" />
                        <path d="M18 8v4" />
                        <path d="M6 8v4" />
                        <path d="M18 16a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                        <path d="M6 19v-7" />
                        <path d="M6 19a3 3 0 0 0 3 3h6" />
                      </svg>
                    </div>
                    <h3 className="text-base font-bold text-white text-center">Precision</h3>
                  </div>
                </div>
              </div>

              <div className="relative">
                <div className="absolute -inset-1 bg-gradient-to-r from-zinc-500 to-zinc-600 rounded-xl blur-xl opacity-20"></div>
                <Image
                  src="/placeholder.svg?height=550&width=800"
                  width={550}
                  height={550}
                  alt="Our Team"
                  className="relative mx-auto aspect-video overflow-hidden rounded-xl object-cover sm:w-full border border-zinc-800"
                />
              </div>
            </div>
          </div>
        </section>

        <section ref={contactRef} id="contact" className="w-full py-16 md:py-24 lg:py-32 bg-zinc-900">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
              <div className="inline-block rounded-lg bg-zinc-800 px-3 py-1 text-sm text-white">Get In Touch</div>
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl text-white">Contact Us</h2>
                <p className="max-w-[900px] text-zinc-400 md:text-xl">
                  Ready to start your project? Get in touch with our team today.
                </p>
              </div>
            </div>

            <div className="grid gap-8 lg:grid-cols-2 lg:gap-12">
              <div className="space-y-6">
                <div className="grid gap-4">
                  <div className="flex items-start space-x-4">
                    <MapPin className="h-6 w-6 text-white mt-0.5" />
                    <div>
                      <h3 className="font-bold text-white">Our Location</h3>
                      <p className="text-zinc-400">
                        5410 NW 33rd Ave #100
                        <br />
                        Fort Lauderdale, FL 33309
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-4">
                    <Phone className="h-6 w-6 text-white mt-0.5" />
                    <div>
                      <h3 className="font-bold text-white">Phone</h3>
                      <p className="text-zinc-400">(555) 123-4567</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-4">
                    <Mail className="h-6 w-6 text-white mt-0.5" />
                    <div>
                      <h3 className="font-bold text-white">Email</h3>
                      <p className="text-zinc-400">info@precisionfabdesign.com</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-4">
                    <Clock className="h-6 w-6 text-white mt-0.5" />
                    <div>
                      <h3 className="font-bold text-white">Business Hours</h3>
                      <p className="text-zinc-400">
                        Monday - Friday: 8:00 AM - 6:00 PM
                        <br />
                        Saturday: 9:00 AM - 2:00 PM
                        <br />
                        Sunday: Closed
                      </p>
                    </div>
                  </div>
                  <div className="mt-6">
                    <h3 className="font-bold text-white mb-2">Our Office</h3>
                    <div className="overflow-hidden rounded-lg border border-zinc-800">
                      <Image
                        src="/images/office.png"
                        width={600}
                        height={400}
                        alt="Our Office Building"
                        className="w-full h-auto"
                      />
                    </div>
                  </div>

                  <div className="mt-6">
                    <h3 className="font-bold text-white mb-2">Our Location</h3>
                    <div className="overflow-hidden rounded-lg border border-zinc-800">
                      <Image
                        src="/images/location-map.jpeg"
                        width={800}
                        height={600}
                        alt="Map location"
                        className="w-full h-auto"
                      />
                    </div>
                    <p className="text-zinc-400 mt-2 text-sm">5410 NW 33rd Ave #100, Fort Lauderdale, FL 33309</p>
                  </div>
                </div>
              </div>

              <Card className="border-zinc-800 bg-zinc-900/50">
                <CardHeader>
                  <CardTitle className="text-white">Send Us a Message</CardTitle>
                  <CardDescription className="text-zinc-400">
                    Fill out the form below and we'll get back to you as soon as possible.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form className="grid gap-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label htmlFor="first-name" className="text-sm font-medium text-white">
                          First name
                        </label>
                        <input
                          id="first-name"
                          placeholder="Enter your first name"
                          className="flex h-10 w-full rounded-md border border-zinc-800 bg-zinc-950 px-3 py-2 text-sm text-white ring-offset-zinc-950 file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-zinc-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-zinc-300 focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                        />
                      </div>
                      <div className="space-y-2">
                        <label htmlFor="last-name" className="text-sm font-medium text-white">
                          Last name
                        </label>
                        <input
                          id="last-name"
                          placeholder="Enter your last name"
                          className="flex h-10 w-full rounded-md border border-zinc-800 bg-zinc-950 px-3 py-2 text-sm text-white ring-offset-zinc-950 file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-zinc-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-zinc-300 focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="email" className="text-sm font-medium text-white">
                        Email
                      </label>
                      <input
                        id="email"
                        type="email"
                        placeholder="Enter your email"
                        className="flex h-10 w-full rounded-md border border-zinc-800 bg-zinc-950 px-3 py-2 text-sm text-white ring-offset-zinc-950 file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-zinc-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-zinc-300 focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      />
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="phone" className="text-sm font-medium text-white">
                        Phone
                      </label>
                      <input
                        id="phone"
                        type="tel"
                        placeholder="Enter your phone number"
                        className="flex h-10 w-full rounded-md border border-zinc-800 bg-zinc-950 px-3 py-2 text-sm text-white ring-offset-zinc-950 file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-zinc-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-zinc-300 focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      />
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="message" className="text-sm font-medium text-white">
                        Message
                      </label>
                      <textarea
                        id="message"
                        placeholder="Enter your message"
                        className="flex min-h-[120px] w-full rounded-md border border-zinc-800 bg-zinc-950 px-3 py-2 text-sm text-white ring-offset-zinc-950 placeholder:text-zinc-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-zinc-300 focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      />
                    </div>
                    <Button type="submit" className="w-full bg-white text-black hover:bg-zinc-200">
                      Send Message
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </main>
      <footer className="w-full border-t border-zinc-800 bg-black">
        <div className="container flex flex-col items-center justify-between gap-4 py-10 md:h-24 md:flex-row md:py-0">
          <div className="flex flex-col items-center gap-4 px-8 md:flex-row md:gap-2 md:px-0">
            <p className="text-center text-sm text-zinc-400 md:text-left">
              &copy; {new Date().getFullYear()} Maker's Lab. All rights reserved.
            </p>
          </div>
          <div className="flex gap-4">
            <Link href="/terms" className="text-sm text-zinc-400 underline-offset-4 hover:text-white hover:underline">
              Terms
            </Link>
            <Link href="/privacy" className="text-sm text-zinc-400 underline-offset-4 hover:text-white hover:underline">
              Privacy
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}

