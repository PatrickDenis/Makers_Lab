"use client"

import type React from "react"

import Link from "next/link"
import Image from "next/image"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft, FileText, Upload, CheckCircle2 } from "lucide-react"

export default function QuotePage() {
  const [step, setStep] = useState(1)
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitted(true)
  }

  return (
    <div className="flex flex-col min-h-screen bg-black text-white">
      <header className="sticky top-0 z-50 w-full border-b border-zinc-800 bg-black/95 backdrop-blur supports-[backdrop-filter]:bg-black/80">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/" className="flex items-center pl-4">
            <Image src="/ML-BKWT.png" alt="Maker's Lab Logo" width={40} height={40} className="mr-2" />
            <span className="text-2xl font-bold text-white">Maker's Lab</span>
          </Link>
          <nav className="hidden md:flex gap-8">
            <Link href="/#services" className="text-sm font-medium text-zinc-400 transition-colors hover:text-white">
              Services
            </Link>
            <Link href="/#gallery" className="text-sm font-medium text-zinc-400 transition-colors hover:text-white">
              Gallery
            </Link>
            <Link href="/#about" className="text-sm font-medium text-zinc-400 transition-colors hover:text-white">
              About
            </Link>
            <Link href="/#contact" className="text-sm font-medium text-zinc-400 transition-colors hover:text-white">
              Contact
            </Link>
          </nav>
          <Button asChild className="hidden md:inline-flex bg-white text-black hover:bg-zinc-200">
            <Link href="/quote">Request Quote</Link>
          </Button>
        </div>
      </header>
      <main className="flex-1 py-16 md:py-24 bg-zinc-900">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
            <Link href="/" className="flex items-center text-sm text-zinc-400 hover:text-white">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Home
            </Link>
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl text-white">
                Request a Quote
              </h1>
              <p className="max-w-[700px] text-zinc-400 md:text-xl">
                Fill out the form below to get a detailed quote for your fabrication project.
              </p>
            </div>
          </div>

          {submitted ? (
            <Card className="max-w-3xl mx-auto border-zinc-800 bg-zinc-900/50">
              <CardContent className="pt-6 flex flex-col items-center text-center">
                <div className="w-16 h-16 rounded-full bg-green-900/20 flex items-center justify-center mb-4 border border-green-700">
                  <CheckCircle2 className="h-8 w-8 text-green-500" />
                </div>
                <h2 className="text-2xl font-bold text-white mb-2">Quote Request Submitted</h2>
                <p className="text-zinc-400 mb-6 max-w-md">
                  Thank you for your quote request. Our team will review your project details and get back to you within
                  24-48 business hours.
                </p>
                <div className="flex flex-col gap-2 sm:flex-row">
                  <Button asChild className="bg-white text-black hover:bg-zinc-200">
                    <Link href="/">Return to Home</Link>
                  </Button>
                  <Button
                    asChild
                    variant="outline"
                    className="border-zinc-700 text-white hover:bg-zinc-800 hover:text-white"
                  >
                    <Link href="/#contact">Contact Us</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card className="max-w-3xl mx-auto border-zinc-800 bg-zinc-900/50">
              <CardHeader>
                <div className="flex justify-between items-center flex-wrap gap-4">
                  <div>
                    <CardTitle className="text-white">Project Details</CardTitle>
                    <CardDescription className="text-zinc-400">
                      Please provide information about your project for an accurate quote.
                    </CardDescription>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <div
                      className={`flex items-center justify-center w-8 h-8 rounded-full ${step >= 1 ? "bg-white text-black" : "bg-zinc-800 text-zinc-500"}`}
                    >
                      1
                    </div>
                    <div className={`w-8 h-1 ${step >= 2 ? "bg-white" : "bg-zinc-800"}`}></div>
                    <div
                      className={`flex items-center justify-center w-8 h-8 rounded-full ${step >= 2 ? "bg-white text-black" : "bg-zinc-800 text-zinc-500"}`}
                    >
                      2
                    </div>
                    <div className={`w-8 h-1 ${step >= 3 ? "bg-white" : "bg-zinc-800"}`}></div>
                    <div
                      className={`flex items-center justify-center w-8 h-8 rounded-full ${step >= 3 ? "bg-white text-black" : "bg-zinc-800 text-zinc-500"}`}
                    >
                      3
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit}>
                  {step === 1 && (
                    <div className="space-y-6">
                      <div className="space-y-4">
                        <h3 className="text-lg font-semibold text-white">Contact Information</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="first-name" className="text-white">
                              First name
                            </Label>
                            <Input
                              id="first-name"
                              placeholder="Enter your first name"
                              required
                              className="border-zinc-800 bg-zinc-950 text-white placeholder:text-zinc-500"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="last-name" className="text-white">
                              Last name
                            </Label>
                            <Input
                              id="last-name"
                              placeholder="Enter your last name"
                              required
                              className="border-zinc-800 bg-zinc-950 text-white placeholder:text-zinc-500"
                            />
                          </div>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="email" className="text-white">
                              Email
                            </Label>
                            <Input
                              id="email"
                              type="email"
                              placeholder="Enter your email"
                              required
                              className="border-zinc-800 bg-zinc-950 text-white placeholder:text-zinc-500"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="phone" className="text-white">
                              Phone
                            </Label>
                            <Input
                              id="phone"
                              type="tel"
                              placeholder="Enter your phone number"
                              required
                              className="border-zinc-800 bg-zinc-950 text-white placeholder:text-zinc-500"
                            />
                          </div>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="company" className="text-white">
                            Company (Optional)
                          </Label>
                          <Input
                            id="company"
                            placeholder="Enter your company name"
                            className="border-zinc-800 bg-zinc-950 text-white placeholder:text-zinc-500"
                          />
                        </div>
                      </div>
                      <div className="flex justify-end">
                        <Button
                          type="button"
                          onClick={() => setStep(2)}
                          className="bg-white text-black hover:bg-zinc-200"
                        >
                          Next Step
                        </Button>
                      </div>
                    </div>
                  )}

                  {step === 2 && (
                    <div className="space-y-6">
                      <div className="space-y-4">
                        <h3 className="text-lg font-semibold text-white">Project Details</h3>
                        <div className="space-y-2">
                          <Label htmlFor="project-name" className="text-white">
                            Project Name
                          </Label>
                          <Input
                            id="project-name"
                            placeholder="Enter a name for your project"
                            required
                            className="border-zinc-800 bg-zinc-950 text-white placeholder:text-zinc-500"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label className="text-white">Service Type</Label>
                          <RadioGroup defaultValue="3d-printing" className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div className="flex items-center space-x-2 border border-zinc-800 rounded-md p-3 cursor-pointer hover:bg-zinc-800">
                              <RadioGroupItem id="3d-printing" value="3d-printing" className="text-white" />
                              <Label htmlFor="3d-printing" className="cursor-pointer text-white">
                                3D Printing
                              </Label>
                            </div>
                            <div className="flex items-center space-x-2 border border-zinc-800 rounded-md p-3 cursor-pointer hover:bg-zinc-800">
                              <RadioGroupItem id="cnc-cutting" value="cnc-cutting" className="text-white" />
                              <Label htmlFor="cnc-cutting" className="cursor-pointer text-white">
                                CNC Cutting
                              </Label>
                            </div>
                            <div className="flex items-center space-x-2 border border-zinc-800 rounded-md p-3 cursor-pointer hover:bg-zinc-800">
                              <RadioGroupItem id="plasma-cutting" value="plasma-cutting" className="text-white" />
                              <Label htmlFor="plasma-cutting" className="cursor-pointer text-white">
                                Plasma Cutting
                              </Label>
                            </div>
                          </RadioGroup>
                        </div>
                        <div className="space-y-2">
                          <Label className="text-white">Material Type</Label>
                          <Select defaultValue="plastic">
                            <SelectTrigger className="border-zinc-800 bg-zinc-950 text-white">
                              <SelectValue placeholder="Select material" />
                            </SelectTrigger>
                            <SelectContent className="border-zinc-800 bg-zinc-950 text-white">
                              <SelectItem value="plastic">Plastic (PLA, ABS, PETG)</SelectItem>
                              <SelectItem value="metal">Metal (Aluminum, Steel)</SelectItem>
                              <SelectItem value="wood">Wood</SelectItem>
                              <SelectItem value="acrylic">Acrylic</SelectItem>
                              <SelectItem value="other">Other (Please specify)</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="quantity" className="text-white">
                            Quantity
                          </Label>
                          <Input
                            id="quantity"
                            type="number"
                            placeholder="Enter quantity needed"
                            min="1"
                            required
                            className="border-zinc-800 bg-zinc-950 text-white placeholder:text-zinc-500"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="timeline" className="text-white">
                            Timeline
                          </Label>
                          <Select defaultValue="standard">
                            <SelectTrigger className="border-zinc-800 bg-zinc-950 text-white">
                              <SelectValue placeholder="Select timeline" />
                            </SelectTrigger>
                            <SelectContent className="border-zinc-800 bg-zinc-950 text-white">
                              <SelectItem value="rush">Rush (1-3 business days)</SelectItem>
                              <SelectItem value="standard">Standard (5-7 business days)</SelectItem>
                              <SelectItem value="extended">Extended (2+ weeks)</SelectItem>
                              <SelectItem value="flexible">Flexible</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <div className="flex justify-between">
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => setStep(1)}
                          className="border-zinc-700 text-white hover:bg-zinc-800 hover:text-white"
                        >
                          Previous
                        </Button>
                        <Button
                          type="button"
                          onClick={() => setStep(3)}
                          className="bg-white text-black hover:bg-zinc-200"
                        >
                          Next Step
                        </Button>
                      </div>
                    </div>
                  )}

                  {step === 3 && (
                    <div className="space-y-6">
                      <div className="space-y-4">
                        <h3 className="text-lg font-semibold text-white">Project Specifications</h3>
                        <div className="space-y-2">
                          <Label htmlFor="description" className="text-white">
                            Project Description
                          </Label>
                          <Textarea
                            id="description"
                            placeholder="Please describe your project in detail"
                            required
                            className="min-h-[120px] border-zinc-800 bg-zinc-950 text-white placeholder:text-zinc-500"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label className="text-white">Do you have design files?</Label>
                          <div className="flex items-center space-x-2 border border-zinc-800 rounded-md p-4 bg-zinc-950">
                            <div className="flex-1">
                              <div className="flex items-center">
                                <FileText className="h-6 w-6 text-zinc-400 mr-2" />
                                <span className="text-sm text-white">Upload CAD files, drawings, or sketches</span>
                              </div>
                              <p className="text-xs text-zinc-500 mt-1">
                                Supported formats: .STL, .STEP, .DWG, .PDF, .JPG, .PNG (Max 10MB)
                              </p>
                            </div>
                            <Button
                              type="button"
                              variant="outline"
                              className="border-zinc-700 text-white hover:bg-zinc-800 hover:text-white"
                            >
                              <Upload className="h-4 w-4 mr-2" />
                              Upload
                            </Button>
                          </div>
                        </div>
                        <div className="space-y-2">
                          <Label className="text-white">Additional Requirements</Label>
                          <div className="space-y-2">
                            <div className="flex items-center space-x-2">
                              <Checkbox
                                id="finishing"
                                className="border-zinc-700 data-[state=checked]:bg-white data-[state=checked]:text-black"
                              />
                              <label
                                htmlFor="finishing"
                                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 text-white"
                              >
                                Surface finishing (sanding, polishing, painting)
                              </label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Checkbox
                                id="assembly"
                                className="border-zinc-700 data-[state=checked]:bg-white data-[state=checked]:text-black"
                              />
                              <label
                                htmlFor="assembly"
                                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 text-white"
                              >
                                Assembly required
                              </label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Checkbox
                                id="design-help"
                                className="border-zinc-700 data-[state=checked]:bg-white data-[state=checked]:text-black"
                              />
                              <label
                                htmlFor="design-help"
                                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 text-white"
                              >
                                Need design assistance
                              </label>
                            </div>
                          </div>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="additional-notes" className="text-white">
                            Additional Notes
                          </Label>
                          <Textarea
                            id="additional-notes"
                            placeholder="Any other information you'd like to share"
                            className="min-h-[80px] border-zinc-800 bg-zinc-950 text-white placeholder:text-zinc-500"
                          />
                        </div>
                      </div>
                      <div className="flex justify-between">
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => setStep(2)}
                          className="border-zinc-700 text-white hover:bg-zinc-800 hover:text-white"
                        >
                          Previous
                        </Button>
                        <Button type="submit" className="bg-white text-black hover:bg-zinc-200">
                          Submit Quote Request
                        </Button>
                      </div>
                    </div>
                  )}
                </form>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
      <footer className="w-full border-t border-zinc-800 bg-black">
        <div className="container flex flex-col items-center justify-between gap-4 py-10 md:h-24 md:flex-row md:py-0">
          <div className="flex flex-col items-center gap-4 px-8 md:flex-row md:gap-2 md:px-0">
            <p className="text-center text-sm text-zinc-400 md:text-left">
              &copy; {new Date().getFullYear()} Maker's Lab. All rights reserved.
            </p>
          </div>
          <div className="flex gap-4">
            <Link href="/terms" className="text-sm text-zinc-400 underline-offset-4 hover:text-white hover:underline">
              Terms
            </Link>
            <Link href="/privacy" className="text-sm text-zinc-400 underline-offset-4 hover:text-white hover:underline">
              Privacy
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}

