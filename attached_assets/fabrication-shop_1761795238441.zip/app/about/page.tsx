import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

export default function AboutPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <Image src="/logo.png" alt="Precision Fab & Design" width={40} height={40} />
            <span className="text-xl font-bold">Precision Fab & Design</span>
          </Link>
          <nav className="hidden md:flex gap-6">
            <Link href="/" className="text-sm font-medium transition-colors hover:text-primary">
              Home
            </Link>
            <Link href="/services" className="text-sm font-medium transition-colors hover:text-primary">
              Services
            </Link>
            <Link href="/gallery" className="text-sm font-medium transition-colors hover:text-primary">
              Gallery
            </Link>
            <Link href="/about" className="text-sm font-medium text-primary">
              About
            </Link>
            <Link href="/contact" className="text-sm font-medium transition-colors hover:text-primary">
              Contact
            </Link>
          </nav>
          <Button asChild className="hidden md:inline-flex">
            <Link href="/contact">Get a Quote</Link>
          </Button>
          <Button variant="outline" size="icon" className="md:hidden">
            <span className="sr-only">Toggle menu</span>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="h-6 w-6"
            >
              <line x1="4" x2="20" y1="12" y2="12" />
              <line x1="4" x2="20" y1="6" y2="6" />
              <line x1="4" x2="20" y1="18" y2="18" />
            </svg>
          </Button>
        </div>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 bg-muted">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl">About Us</h1>
                <p className="max-w-[900px] text-muted-foreground md:text-xl">
                  Learn about our company, our mission, and the team behind Precision Fab & Design.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-[1fr_400px] lg:gap-12 xl:grid-cols-[1fr_600px]">
              <div className="flex flex-col justify-center space-y-4">
                <div className="space-y-2">
                  <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl">Our Story</h2>
                  <p className="text-muted-foreground md:text-xl">
                    Founded in 2010, Precision Fab & Design began as a small workshop with a single CNC machine and a
                    passion for precision manufacturing.
                  </p>
                </div>
                <div className="space-y-4">
                  <p>
                    What started as a one-person operation has grown into a full-service fabrication shop with
                    state-of-the-art equipment and a team of skilled technicians. Our journey has been driven by a
                    commitment to quality, innovation, and customer satisfaction.
                  </p>
                  <p>
                    Over the years, we've expanded our capabilities to include 3D printing, CNC cutting, and plasma
                    cutting services, allowing us to serve a diverse range of industries including aerospace,
                    automotive, construction, and more.
                  </p>
                  <p>
                    Today, we continue to invest in the latest technology and training to ensure we can meet the
                    evolving needs of our clients and deliver exceptional results on every project.
                  </p>
                </div>
              </div>
              <Image
                src="/placeholder.svg?height=550&width=800"
                width={550}
                height={550}
                alt="Our Workshop"
                className="mx-auto aspect-video overflow-hidden rounded-xl object-cover sm:w-full lg:order-last"
              />
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 lg:py-32 bg-muted">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl">Our Mission</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl">
                  We strive to deliver exceptional fabrication services that bring our clients' visions to life with
                  precision, quality, and innovation.
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl items-center gap-6 py-12 lg:grid-cols-3 lg:gap-12">
              <Card className="relative overflow-hidden">
                <CardContent className="p-6">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 mb-4">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="h-6 w-6 text-primary"
                    >
                      <path d="m22 8-6 4 6 4V8Z" />
                      <rect x="2" y="6" width="14" height="12" rx="2" />
                    </svg>
                  </div>
                  <h3 className="text-xl font-bold">Quality</h3>
                  <p className="text-muted-foreground mt-2">
                    We are committed to delivering the highest quality products that meet or exceed our clients'
                    expectations.
                  </p>
                </CardContent>
              </Card>
              <Card className="relative overflow-hidden">
                <CardContent className="p-6">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 mb-4">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="h-6 w-6 text-primary"
                    >
                      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10" />
                    </svg>
                  </div>
                  <h3 className="text-xl font-bold">Integrity</h3>
                  <p className="text-muted-foreground mt-2">
                    We operate with honesty, transparency, and ethical business practices in all our dealings.
                  </p>
                </CardContent>
              </Card>
              <Card className="relative overflow-hidden">
                <CardContent className="p-6">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 mb-4">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="h-6 w-6 text-primary"
                    >
                      <path d="M18 6H5a2 2 0 0 0-2 2v3a2 2 0 0 0 2 2h13l4-3.5L18 6Z" />
                      <path d="M12 13v8" />
                      <path d="M5 13v6a2 2 0 0 0 2 2h8" />
                    </svg>
                  </div>
                  <h3 className="text-xl font-bold">Innovation</h3>
                  <p className="text-muted-foreground mt-2">
                    We continuously explore new technologies and techniques to improve our services and capabilities.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl">Our Team</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl">
                  Meet the skilled professionals who make our precision fabrication possible.
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl items-center gap-6 py-12 md:grid-cols-2 lg:grid-cols-3 lg:gap-12">
              {[
                {
                  name: "John Smith",
                  title: "Founder & CEO",
                  bio: "With over 20 years of experience in precision manufacturing, John leads our team with expertise and vision.",
                },
                {
                  name: "Sarah Johnson",
                  title: "Lead Designer",
                  bio: "Sarah brings creative solutions to complex design challenges, helping clients transform ideas into reality.",
                },
                {
                  name: "Michael Chen",
                  title: "CNC Specialist",
                  bio: "Michael's attention to detail and technical knowledge ensures precision in every CNC project we undertake.",
                },
                {
                  name: "Emily Rodriguez",
                  title: "3D Printing Expert",
                  bio: "Emily stays at the cutting edge of additive manufacturing, pushing the boundaries of what's possible.",
                },
                {
                  name: "David Wilson",
                  title: "Plasma Cutting Technician",
                  bio: "David's craftsmanship with plasma cutting technology delivers exceptional results for our clients.",
                },
                {
                  name: "Lisa Thompson",
                  title: "Project Manager",
                  bio: "Lisa ensures that every project runs smoothly from concept to completion, keeping clients informed every step of the way.",
                },
              ].map((member, i) => (
                <Card key={i} className="relative overflow-hidden">
                  <CardContent className="p-6 flex flex-col items-center text-center">
                    <div className="w-24 h-24 rounded-full bg-muted mb-4 overflow-hidden">
                      <Image
                        src={`/placeholder.svg?height=96&width=96&text=${member.name.split(" ")[0][0]}${member.name.split(" ")[1][0]}`}
                        width={96}
                        height={96}
                        alt={member.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <h3 className="text-xl font-bold">{member.name}</h3>
                    <p className="text-sm text-primary">{member.title}</p>
                    <p className="text-muted-foreground mt-2">{member.bio}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 lg:py-32 bg-muted">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl">Our Facility</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl">
                  Our state-of-the-art workshop is equipped with the latest technology to handle projects of any size.
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl items-center gap-6 py-12 md:grid-cols-2 lg:gap-12">
              <Image
                src="/placeholder.svg?height=400&width=600&text=Workshop"
                width={600}
                height={400}
                alt="Workshop"
                className="rounded-lg overflow-hidden"
              />
              <Image
                src="/placeholder.svg?height=400&width=600&text=Equipment"
                width={600}
                height={400}
                alt="Equipment"
                className="rounded-lg overflow-hidden"
              />
              <Image
                src="/placeholder.svg?height=400&width=600&text=3D+Printers"
                width={600}
                height={400}
                alt="3D Printers"
                className="rounded-lg overflow-hidden"
              />
              <Image
                src="/placeholder.svg?height=400&width=600&text=CNC+Machines"
                width={600}
                height={400}
                alt="CNC Machines"
                className="rounded-lg overflow-hidden"
              />
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl">Ready to Work With Us?</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl">
                  Contact our team today to discuss your project and how we can help bring your ideas to life.
                </p>
              </div>
              <div className="flex flex-col gap-2 min-[400px]:flex-row">
                <Button asChild size="lg">
                  <Link href="/contact">Contact Us</Link>
                </Button>
                <Button asChild variant="outline" size="lg">
                  <Link href="/services">Explore Our Services</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="w-full border-t bg-background">
        <div className="container flex flex-col items-center justify-between gap-4 py-10 md:h-24 md:flex-row md:py-0">
          <div className="flex flex-col items-center gap-4 px-8 md:flex-row md:gap-2 md:px-0">
            <Image src="/logo.png" alt="Precision Fab & Design" width={30} height={30} />
            <p className="text-center text-sm leading-loose md:text-left">
              &copy; {new Date().getFullYear()} Precision Fab & Design. All rights reserved.
            </p>
          </div>
          <div className="flex gap-4">
            <Link href="/terms" className="text-sm text-muted-foreground underline-offset-4 hover:underline">
              Terms
            </Link>
            <Link href="/privacy" className="text-sm text-muted-foreground underline-offset-4 hover:underline">
              Privacy
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}

