import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function GalleryPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <Image src="/logo.png" alt="Precision Fab & Design" width={40} height={40} />
            <span className="text-xl font-bold">Precision Fab & Design</span>
          </Link>
          <nav className="hidden md:flex gap-6">
            <Link href="/" className="text-sm font-medium transition-colors hover:text-primary">
              Home
            </Link>
            <Link href="/services" className="text-sm font-medium transition-colors hover:text-primary">
              Services
            </Link>
            <Link href="/gallery" className="text-sm font-medium text-primary">
              Gallery
            </Link>
            <Link href="/about" className="text-sm font-medium transition-colors hover:text-primary">
              About
            </Link>
            <Link href="/contact" className="text-sm font-medium transition-colors hover:text-primary">
              Contact
            </Link>
          </nav>
          <Button asChild className="hidden md:inline-flex">
            <Link href="/contact">Get a Quote</Link>
          </Button>
          <Button variant="outline" size="icon" className="md:hidden">
            <span className="sr-only">Toggle menu</span>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="h-6 w-6"
            >
              <line x1="4" x2="20" y1="12" y2="12" />
              <line x1="4" x2="20" y1="6" y2="6" />
              <line x1="4" x2="20" y1="18" y2="18" />
            </svg>
          </Button>
        </div>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 bg-muted">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl">Our Work</h1>
                <p className="max-w-[900px] text-muted-foreground md:text-xl">
                  Browse our portfolio of completed projects across various industries and applications.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <Tabs defaultValue="all" className="w-full">
              <div className="flex justify-center mb-8">
                <TabsList>
                  <TabsTrigger value="all">All Projects</TabsTrigger>
                  <TabsTrigger value="3d-printing">3D Printing</TabsTrigger>
                  <TabsTrigger value="cnc-cutting">CNC Cutting</TabsTrigger>
                  <TabsTrigger value="plasma-cutting">Plasma Cutting</TabsTrigger>
                </TabsList>
              </div>
              <TabsContent value="all" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {[...Array(9)].map((_, i) => (
                    <div key={i} className="overflow-hidden rounded-lg border">
                      <Image
                        src={`/placeholder.svg?height=300&width=400&text=Project+${i + 1}`}
                        width={400}
                        height={300}
                        alt={`Project ${i + 1}`}
                        className="aspect-video object-cover w-full"
                      />
                      <div className="p-4">
                        <h3 className="font-bold">Project {i + 1}</h3>
                        <p className="text-sm text-muted-foreground">
                          {i % 3 === 0
                            ? "3D Printed prototype for aerospace application"
                            : i % 3 === 1
                              ? "CNC machined aluminum components"
                              : "Plasma cut steel signage"}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </TabsContent>
              <TabsContent value="3d-printing" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {[...Array(3)].map((_, i) => (
                    <div key={i} className="overflow-hidden rounded-lg border">
                      <Image
                        src={`/placeholder.svg?height=300&width=400&text=3D+Print+${i + 1}`}
                        width={400}
                        height={300}
                        alt={`3D Print Project ${i + 1}`}
                        className="aspect-video object-cover w-full"
                      />
                      <div className="p-4">
                        <h3 className="font-bold">3D Print Project {i + 1}</h3>
                        <p className="text-sm text-muted-foreground">3D Printed prototype for aerospace application</p>
                      </div>
                    </div>
                  ))}
                </div>
              </TabsContent>
              <TabsContent value="cnc-cutting" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {[...Array(3)].map((_, i) => (
                    <div key={i} className="overflow-hidden rounded-lg border">
                      <Image
                        src={`/placeholder.svg?height=300&width=400&text=CNC+Project+${i + 1}`}
                        width={400}
                        height={300}
                        alt={`CNC Project ${i + 1}`}
                        className="aspect-video object-cover w-full"
                      />
                      <div className="p-4">
                        <h3 className="font-bold">CNC Project {i + 1}</h3>
                        <p className="text-sm text-muted-foreground">CNC machined aluminum components</p>
                      </div>
                    </div>
                  ))}
                </div>
              </TabsContent>
              <TabsContent value="plasma-cutting" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {[...Array(3)].map((_, i) => (
                    <div key={i} className="overflow-hidden rounded-lg border">
                      <Image
                        src={`/placeholder.svg?height=300&width=400&text=Plasma+Project+${i + 1}`}
                        width={400}
                        height={300}
                        alt={`Plasma Project ${i + 1}`}
                        className="aspect-video object-cover w-full"
                      />
                      <div className="p-4">
                        <h3 className="font-bold">Plasma Project {i + 1}</h3>
                        <p className="text-sm text-muted-foreground">Plasma cut steel signage</p>
                      </div>
                    </div>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 lg:py-32 bg-muted">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl">Have a Project in Mind?</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl">
                  Let us help bring your ideas to life with our expert fabrication services.
                </p>
              </div>
              <div className="flex flex-col gap-2 min-[400px]:flex-row">
                <Button asChild size="lg">
                  <Link href="/contact">Start Your Project</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="w-full border-t bg-background">
        <div className="container flex flex-col items-center justify-between gap-4 py-10 md:h-24 md:flex-row md:py-0">
          <div className="flex flex-col items-center gap-4 px-8 md:flex-row md:gap-2 md:px-0">
            <Image src="/logo.png" alt="Precision Fab & Design" width={30} height={30} />
            <p className="text-center text-sm leading-loose md:text-left">
              &copy; {new Date().getFullYear()} Precision Fab & Design. All rights reserved.
            </p>
          </div>
          <div className="flex gap-4">
            <Link href="/terms" className="text-sm text-muted-foreground underline-offset-4 hover:underline">
              Terms
            </Link>
            <Link href="/privacy" className="text-sm text-muted-foreground underline-offset-4 hover:underline">
              Privacy
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}

